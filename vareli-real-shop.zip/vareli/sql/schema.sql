create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(), name text not null, slug text unique not null, created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(), name text not null, description text default '', price integer not null check(price >= 0), image_url text, category_id uuid references public.categories(id) on delete set null, stock integer not null default 0 check(stock >= 0), is_active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(), customer_name text not null, phone text not null, address text not null, note text default '', total integer not null default 0, status text not null default 'new' check(status in ('new','confirmed','shipped','done','cancelled')), created_at timestamptz not null default now()
);
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(), order_id uuid not null references public.orders(id) on delete cascade, product_id uuid references public.products(id) on delete set null, product_name text not null, price integer not null, quantity integer not null check(quantity > 0)
);

insert into public.categories(name,slug) values ('Գեղեցկություն','beauty'),('Աքսեսուարներ','accessories'),('Նորույթներ','new') on conflict (slug) do nothing;

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
grant execute on function public.is_admin() to anon, authenticated;

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

create policy "profile own" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
create policy "categories public read" on public.categories for select using(true);
create policy "categories admin write" on public.categories for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "products public active read" on public.products for select using(is_active=true);
create policy "products admin all" on public.products for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "orders admin read" on public.orders for select to authenticated using(public.is_admin());
create policy "orders admin update" on public.orders for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "items admin read" on public.order_items for select to authenticated using(public.is_admin());

create or replace function public.create_order(p_customer_name text,p_phone text,p_address text,p_note text,p_items jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_order uuid; v_total integer:=0; x jsonb; p public.products%rowtype; q integer; pid uuid;
begin
  if jsonb_array_length(p_items)=0 then raise exception 'Cart is empty'; end if;
  insert into public.orders(customer_name,phone,address,note,total) values(trim(p_customer_name),trim(p_phone),trim(p_address),coalesce(p_note,''),0) returning id into v_order;
  for x in select * from jsonb_array_elements(p_items) loop
    pid := (x->>'product_id')::uuid; q := (x->>'quantity')::integer;
    if q is null or q < 1 or q > 100 then raise exception 'Invalid quantity'; end if;
    select * into p from public.products where id=pid and is_active=true for update;
    if not found then raise exception 'Product not found'; end if;
    if p.stock < q then raise exception 'Not enough stock for %', p.name; end if;
    v_total := v_total + p.price*q;
    insert into public.order_items(order_id,product_id,product_name,price,quantity) values(v_order,p.id,p.name,p.price,q);
    update public.products set stock=stock-q where id=p.id;
  end loop;
  update public.orders set total=v_total where id=v_order;
  return v_order;
end; $$;
grant execute on function public.create_order(text,text,text,text,jsonb) to anon, authenticated;

insert into storage.buckets(id,name,public) values('products','products',true) on conflict(id) do nothing;
create policy "product images public read" on storage.objects for select using(bucket_id='products');
create policy "product images admin insert" on storage.objects for insert to authenticated with check(bucket_id='products' and public.is_admin());
create policy "product images admin update" on storage.objects for update to authenticated using(bucket_id='products' and public.is_admin()) with check(bucket_id='products' and public.is_admin());
create policy "product images admin delete" on storage.objects for delete to authenticated using(bucket_id='products' and public.is_admin());
