# Vareli — real shop + Admin + Supabase database

## 1. Install
npm install

## 2. Supabase
Create a Supabase project. Open SQL Editor and run `sql/schema.sql`.

Then create an Auth user (email/password) for the admin. Copy that user's UUID and run:

insert into public.profiles(id, role) values ('YOUR_USER_UUID','admin') on conflict (id) do update set role='admin';

## 3. Environment
Copy `.env.example` to `.env.local` and fill:
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=

## 4. Run
npm run dev

Open http://localhost:3000
Admin: http://localhost:3000/admin/login

Features: products CRUD, image upload to Supabase Storage, categories, stock, cart, server-side order total/stock validation, orders and status management, admin role/RLS.
