import './style.css'
export const metadata={title:'Vareli',description:'Vareli online shop'}
export default function Layout({children}){return <html lang="hy"><body>{children}</body></html>}
